/*
   New Perspectives on HTML5 and CSS3 and JavaScript, 6th Edition
   Tutorial 9

   Planisphere Script
   Author: 
   Date:   

*/

