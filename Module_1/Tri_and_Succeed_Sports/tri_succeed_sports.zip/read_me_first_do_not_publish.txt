These are the starter files from the textbook.  HOWEVER, they have been organized into subfolders.

Any referenced links to Images, Fonts, and Styles will need to be linked to the appropriate subfolders, which will differ slightly from the author's instructions.

Example:

Instead of <img src="tss_logo.png"> linking in the same folder, it will now need to be modified to <img scr="images/tss_logo.png"> (so it points to the images folder first).  You'll do the same with styles and fonts.

This will keep the html separate from other files, and help you better organize your project.

Any questions, use Piazza!